export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname.slice(1);
    
    // Get user email from Cloudflare Access JWT
    const userEmail = await getUserEmail(request);
    
    // Public redirect - no auth needed
    if (path && !path.startsWith('admin') && !path.startsWith('api/')) {
      const link = await env.DB.prepare('SELECT destination FROM links WHERE code = ?').bind(path).first();
      if (link) {
        await env.DB.prepare('UPDATE links SET clicks = clicks + 1 WHERE code = ?').bind(path).run();
        return Response.redirect(link.destination, 302);
      }
      return new Response('Not found', { status: 404 });
    }
    
    // Protected routes require auth
    if (!userEmail) {
      return new Response('Unauthorized - Cloudflare Access required', { status: 401 });
    }
    
    // Admin page
    if (path === 'admin') {
      return new Response(getAdminHTML(userEmail), { headers: { 'Content-Type': 'text/html' } });
    }
    
    // List user's links
    if (path === 'api/links' && request.method === 'GET') {
      const { results } = await env.DB.prepare('SELECT * FROM links WHERE user_email = ? ORDER BY created_at DESC').bind(userEmail).all();
      return Response.json(results);
    }
    
    // Create new link
    if (path === 'api/links' && request.method === 'POST') {
      const { code, destination } = await request.json();
      if (!code || !destination) {
        return Response.json({ error: 'Missing code or destination' }, { status: 400 });
      }
      // Check if code exists globally (short codes must be unique across all users)
      const existing = await env.DB.prepare('SELECT code FROM links WHERE code = ?').bind(code).first();
      if (existing) {
        return Response.json({ error: 'Code already taken' }, { status: 409 });
      }
      try {
        await env.DB.prepare('INSERT INTO links (code, destination, user_email) VALUES (?, ?, ?)').bind(code, destination, userEmail).run();
        return Response.json({ success: true, code, destination });
      } catch (e) {
        return Response.json({ error: 'Failed to create link' }, { status: 500 });
      }
    }
    
    // Delete link (only own links)
    if (path.startsWith('api/links/') && request.method === 'DELETE') {
      const code = path.replace('api/links/', '');
      await env.DB.prepare('DELETE FROM links WHERE code = ? AND user_email = ?').bind(code, userEmail).run();
      return Response.json({ success: true });
    }
    
    // Export user's links
    if (path === 'api/export' && request.method === 'GET') {
      const { results } = await env.DB.prepare('SELECT code, destination, clicks, created_at FROM links WHERE user_email = ? ORDER BY created_at DESC').bind(userEmail).all();
      return new Response(JSON.stringify(results, null, 2), {
        headers: {
          'Content-Type': 'application/json',
          'Content-Disposition': `attachment; filename="links-export-${new Date().toISOString().split('T')[0]}.json"`
        }
      });
    }
    
    // Import links
    if (path === 'api/import' && request.method === 'POST') {
      try {
        const links = await request.json();
        let imported = 0;
        let skipped = 0;
        
        for (const link of links) {
          if (!link.code || !link.destination) continue;
          
          // Check if code exists
          const existing = await env.DB.prepare('SELECT code FROM links WHERE code = ?').bind(link.code).first();
          if (existing) {
            skipped++;
            continue;
          }
          
          await env.DB.prepare('INSERT INTO links (code, destination, user_email, clicks) VALUES (?, ?, ?, ?)').bind(link.code, link.destination, userEmail, link.clicks || 0).run();
          imported++;
        }
        
        return Response.json({ success: true, imported, skipped });
      } catch (e) {
        return Response.json({ error: 'Invalid JSON format' }, { status: 400 });
      }
    }
    
    return new Response('Not found', { status: 404 });
  }
};

// Decode Cloudflare Access JWT to get user email
async function getUserEmail(request) {
  const jwt = request.headers.get('Cf-Access-Jwt-Assertion');
  if (!jwt) return null;
  
  try {
    // JWT is base64url encoded: header.payload.signature
    const parts = jwt.split('.');
    if (parts.length !== 3) return null;
    
    // Decode payload (middle part)
    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
    return payload.email || null;
  } catch (e) {
    return null;
  }
}

function getAdminHTML(userEmail) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Link Shortener</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-primary: #0a0a0f;
      --bg-secondary: #12121a;
      --bg-card: #1a1a24;
      --bg-hover: #22222e;
      --border: #2a2a3a;
      --text-primary: #ffffff;
      --text-secondary: #a0a0b0;
      --text-muted: #606070;
      --accent: #6366f1;
      --accent-hover: #4f46e5;
      --accent-glow: rgba(99, 102, 241, 0.2);
      --success: #10b981;
      --success-glow: rgba(16, 185, 129, 0.2);
      --danger: #ef4444;
      --danger-hover: #dc2626;
      --gradient-1: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #d946ef 100%);
      --gradient-2: linear-gradient(135deg, #0a0a0f 0%, #12121a 100%);
    }
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
      background: var(--bg-primary);
      color: var(--text-primary);
      min-height: 100vh;
      line-height: 1.6;
    }
    
    /* Animated background */
    .bg-pattern {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-image: 
        radial-gradient(circle at 20% 50%, var(--accent-glow) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(139, 92, 246, 0.1) 0%, transparent 40%),
        radial-gradient(circle at 40% 80%, rgba(217, 70, 239, 0.08) 0%, transparent 40%);
      pointer-events: none;
      z-index: 0;
    }
    
    .container {
      max-width: 1000px;
      margin: 0 auto;
      padding: 2rem;
      position: relative;
      z-index: 1;
    }
    
    /* Header */
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2.5rem;
      flex-wrap: wrap;
      gap: 1.5rem;
    }
    
    .logo {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }
    
    .logo-icon {
      width: 48px;
      height: 48px;
      background: var(--gradient-1);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      box-shadow: 0 4px 20px var(--accent-glow);
    }
    
    .logo h1 {
      font-size: 1.5rem;
      font-weight: 700;
      background: var(--gradient-1);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    
    .user-section {
      display: flex;
      align-items: center;
      gap: 1rem;
      flex-wrap: wrap;
    }
    
    .user-badge {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      background: var(--bg-card);
      padding: 0.5rem 1rem;
      border-radius: 100px;
      border: 1px solid var(--border);
      font-size: 0.875rem;
    }
    
    .user-avatar {
      width: 24px;
      height: 24px;
      background: var(--gradient-1);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .user-email {
      color: var(--text-secondary);
    }
    
    /* Buttons */
    .btn {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.625rem 1.25rem;
      border: none;
      border-radius: 8px;
      font-size: 0.875rem;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.2s ease;
      font-family: inherit;
    }
    
    .btn-primary {
      background: var(--accent);
      color: white;
      box-shadow: 0 2px 10px var(--accent-glow);
    }
    
    .btn-primary:hover {
      background: var(--accent-hover);
      transform: translateY(-1px);
      box-shadow: 0 4px 20px var(--accent-glow);
    }
    
    .btn-secondary {
      background: var(--bg-card);
      color: var(--text-primary);
      border: 1px solid var(--border);
    }
    
    .btn-secondary:hover {
      background: var(--bg-hover);
      border-color: var(--text-muted);
    }
    
    .btn-ghost {
      background: transparent;
      color: var(--text-secondary);
      padding: 0.5rem;
    }
    
    .btn-ghost:hover {
      background: var(--bg-hover);
      color: var(--text-primary);
    }
    
    .btn-danger {
      background: transparent;
      color: var(--danger);
      border: 1px solid var(--danger);
    }
    
    .btn-danger:hover {
      background: var(--danger);
      color: white;
    }
    
    .toolbar {
      display: flex;
      gap: 0.5rem;
    }
    
    /* Stats Cards */
    .stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
      margin-bottom: 2rem;
    }
    
    .stat-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 1.5rem;
      position: relative;
      overflow: hidden;
    }
    
    .stat-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      background: var(--gradient-1);
    }
    
    .stat-icon {
      width: 40px;
      height: 40px;
      background: var(--accent-glow);
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 1rem;
      font-size: 1.25rem;
    }
    
    .stat-value {
      font-size: 2rem;
      font-weight: 700;
      color: var(--text-primary);
      line-height: 1.2;
    }
    
    .stat-label {
      font-size: 0.875rem;
      color: var(--text-muted);
      margin-top: 0.25rem;
    }
    
    /* Create Form */
    .create-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 1.5rem;
      margin-bottom: 2rem;
    }
    
    .create-card h2 {
      font-size: 1rem;
      font-weight: 600;
      margin-bottom: 1rem;
      color: var(--text-secondary);
    }
    
    .form-row {
      display: flex;
      gap: 1rem;
      flex-wrap: wrap;
    }
    
    .input-group {
      flex: 1;
      min-width: 200px;
    }
    
    .input-group label {
      display: block;
      font-size: 0.75rem;
      font-weight: 500;
      color: var(--text-muted);
      margin-bottom: 0.5rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    
    input[type="text"],
    input[type="url"] {
      width: 100%;
      padding: 0.875rem 1rem;
      background: var(--bg-secondary);
      border: 1px solid var(--border);
      border-radius: 10px;
      color: var(--text-primary);
      font-size: 0.9375rem;
      font-family: inherit;
      transition: all 0.2s ease;
    }
    
    input[type="text"]:focus,
    input[type="url"]:focus {
      outline: none;
      border-color: var(--accent);
      box-shadow: 0 0 0 3px var(--accent-glow);
    }
    
    input::placeholder {
      color: var(--text-muted);
    }
    
    /* Links Table */
    .links-card {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      overflow: hidden;
    }
    
    .links-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.25rem 1.5rem;
      border-bottom: 1px solid var(--border);
    }
    
    .links-header h2 {
      font-size: 1rem;
      font-weight: 600;
    }
    
    .search-box {
      position: relative;
    }
    
    .search-box input {
      padding: 0.5rem 1rem 0.5rem 2.25rem;
      background: var(--bg-secondary);
      border: 1px solid var(--border);
      border-radius: 8px;
      color: var(--text-primary);
      font-size: 0.875rem;
      width: 200px;
    }
    
    .search-box::before {
      content: '🔍';
      position: absolute;
      left: 0.75rem;
      top: 50%;
      transform: translateY(-50%);
      font-size: 0.75rem;
      opacity: 0.5;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
    }
    
    th {
      text-align: left;
      padding: 0.875rem 1.5rem;
      font-size: 0.75rem;
      font-weight: 600;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: 0.05em;
      background: var(--bg-secondary);
      border-bottom: 1px solid var(--border);
    }
    
    td {
      padding: 1rem 1.5rem;
      border-bottom: 1px solid var(--border);
      vertical-align: middle;
    }
    
    tr:last-child td {
      border-bottom: none;
    }
    
    tr:hover td {
      background: var(--bg-hover);
    }
    
    .link-code {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
    }
    
    .link-code a {
      font-family: 'SF Mono', Monaco, 'Courier New', monospace;
      font-size: 0.875rem;
      color: var(--accent);
      text-decoration: none;
      padding: 0.375rem 0.75rem;
      background: var(--accent-glow);
      border-radius: 6px;
      transition: all 0.2s ease;
    }
    
    .link-code a:hover {
      background: var(--accent);
      color: white;
    }
    
    .copy-btn {
      opacity: 0;
      transition: opacity 0.2s ease;
    }
    
    tr:hover .copy-btn {
      opacity: 1;
    }
    
    .destination {
      max-width: 300px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: var(--text-secondary);
      font-size: 0.875rem;
    }
    
    .destination a {
      color: var(--text-secondary);
      text-decoration: none;
    }
    
    .destination a:hover {
      color: var(--text-primary);
    }
    
    .clicks-badge {
      display: inline-flex;
      align-items: center;
      gap: 0.375rem;
      padding: 0.375rem 0.75rem;
      background: var(--success-glow);
      color: var(--success);
      border-radius: 100px;
      font-size: 0.8125rem;
      font-weight: 500;
    }
    
    .date {
      color: var(--text-muted);
      font-size: 0.8125rem;
    }
    
    .actions {
      display: flex;
      gap: 0.5rem;
      justify-content: flex-end;
    }
    
    .empty-state {
      text-align: center;
      padding: 4rem 2rem;
      color: var(--text-muted);
    }
    
    .empty-state-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
      opacity: 0.5;
    }
    
    .empty-state h3 {
      font-size: 1.125rem;
      color: var(--text-secondary);
      margin-bottom: 0.5rem;
    }
    
    /* Toast */
    .toast {
      position: fixed;
      bottom: 2rem;
      right: 2rem;
      padding: 1rem 1.5rem;
      border-radius: 12px;
      color: white;
      font-weight: 500;
      font-size: 0.875rem;
      opacity: 0;
      transform: translateY(1rem);
      transition: all 0.3s ease;
      z-index: 1000;
      display: flex;
      align-items: center;
      gap: 0.5rem;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
    }
    
    .toast.success {
      background: var(--success);
    }
    
    .toast.error {
      background: var(--danger);
    }
    
    .toast.show {
      opacity: 1;
      transform: translateY(0);
    }
    
    /* Hidden file input */
    input[type="file"] {
      display: none;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .container {
        padding: 1rem;
      }
      
      header {
        flex-direction: column;
        align-items: flex-start;
      }
      
      .stats {
        grid-template-columns: 1fr 1fr;
      }
      
      .form-row {
        flex-direction: column;
      }
      
      .input-group {
        min-width: 100%;
      }
      
      th, td {
        padding: 0.75rem 1rem;
      }
      
      .destination {
        max-width: 150px;
      }
      
      .date {
        display: none;
      }
    }
    
    /* Animations */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .stat-card, .create-card, .links-card {
      animation: fadeIn 0.4s ease;
    }
    
    .stat-card:nth-child(2) { animation-delay: 0.1s; }
    .stat-card:nth-child(3) { animation-delay: 0.2s; }
  </style>
</head>
<body>
  <div class="bg-pattern"></div>
  
  <div class="container">
    <header>
      <div class="logo">
        <div class="logo-icon">🔗</div>
        <h1>Link Shortener</h1>
      </div>
      <div class="user-section">
        <div class="user-badge">
          <div class="user-avatar">${userEmail.charAt(0).toUpperCase()}</div>
          <span class="user-email">${userEmail}</span>
        </div>
        <div class="toolbar">
          <button class="btn btn-secondary" onclick="exportLinks()">
            <span>📤</span> Export
          </button>
          <label class="btn btn-secondary" style="cursor: pointer;">
            <span>📥</span> Import
            <input type="file" id="importFile" accept=".json" onchange="importLinks(event)">
          </label>
        </div>
      </div>
    </header>
    
    <div class="stats">
      <div class="stat-card">
        <div class="stat-icon">🔗</div>
        <div class="stat-value" id="totalLinks">-</div>
        <div class="stat-label">Total Links</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">📊</div>
        <div class="stat-value" id="totalClicks">-</div>
        <div class="stat-label">Total Clicks</div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">⚡</div>
        <div class="stat-value" id="avgClicks">-</div>
        <div class="stat-label">Avg. Clicks</div>
      </div>
    </div>
    
    <div class="create-card">
      <h2>Create New Link</h2>
      <div class="form-row">
        <div class="input-group">
          <label for="code">Short Code</label>
          <input type="text" id="code" placeholder="e.g. portfolio">
        </div>
        <div class="input-group" style="flex: 2;">
          <label for="destination">Destination URL</label>
          <input type="url" id="destination" placeholder="https://example.com/your-long-url">
        </div>
        <div class="input-group" style="flex: 0; align-self: flex-end;">
          <button class="btn btn-primary" onclick="addLink()" style="height: 46px;">
            <span>✨</span> Create
          </button>
        </div>
      </div>
    </div>
    
    <div class="links-card">
      <div class="links-header">
        <h2>Your Links</h2>
        <div class="search-box">
          <input type="text" id="search" placeholder="Search..." oninput="filterLinks()">
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>Short Link</th>
            <th>Destination</th>
            <th>Clicks</th>
            <th>Created</th>
            <th></th>
          </tr>
        </thead>
        <tbody id="links"></tbody>
      </table>
    </div>
  </div>
  
  <div class="toast" id="toast"></div>

  <script>
    const baseUrl = window.location.origin;
    let allLinks = [];
    
    async function loadLinks() {
      const res = await fetch('/api/links');
      allLinks = await res.json();
      
      // Update stats
      document.getElementById('totalLinks').textContent = allLinks.length;
      const totalClicks = allLinks.reduce((sum, l) => sum + (l.clicks || 0), 0);
      document.getElementById('totalClicks').textContent = totalClicks.toLocaleString();
      document.getElementById('avgClicks').textContent = allLinks.length ? (totalClicks / allLinks.length).toFixed(1) : '0';
      
      renderLinks(allLinks);
    }
    
    function renderLinks(links) {
      const tbody = document.getElementById('links');
      
      if (links.length === 0) {
        tbody.innerHTML = \`
          <tr>
            <td colspan="5">
              <div class="empty-state">
                <div class="empty-state-icon">🔗</div>
                <h3>No links yet</h3>
                <p>Create your first short link above</p>
              </div>
            </td>
          </tr>
        \`;
        return;
      }
      
      tbody.innerHTML = links.map(link => {
        const date = new Date(link.created_at).toLocaleDateString('en-US', { 
          month: 'short', 
          day: 'numeric',
          year: link.created_at?.startsWith(new Date().getFullYear()) ? undefined : 'numeric'
        });
        
        return \`
          <tr>
            <td>
              <div class="link-code">
                <a href="\${baseUrl}/\${link.code}" target="_blank">/\${link.code}</a>
                <button class="btn btn-ghost copy-btn" onclick="copyLink('\${link.code}')" title="Copy link">
                  📋
                </button>
              </div>
            </td>
            <td>
              <div class="destination">
                <a href="\${link.destination}" target="_blank" title="\${link.destination}">\${link.destination}</a>
              </div>
            </td>
            <td>
              <span class="clicks-badge">
                <span>📈</span>
                \${link.clicks.toLocaleString()}
              </span>
            </td>
            <td><span class="date">\${date}</span></td>
            <td>
              <div class="actions">
                <button class="btn btn-danger" onclick="deleteLink('\${link.code}')">Delete</button>
              </div>
            </td>
          </tr>
        \`;
      }).join('');
    }
    
    function filterLinks() {
      const search = document.getElementById('search').value.toLowerCase();
      const filtered = allLinks.filter(link => 
        link.code.toLowerCase().includes(search) || 
        link.destination.toLowerCase().includes(search)
      );
      renderLinks(filtered);
    }
    
    async function addLink() {
      const code = document.getElementById('code').value.trim();
      const destination = document.getElementById('destination').value.trim();
      
      if (!code || !destination) {
        showToast('Please fill in both fields', 'error');
        return;
      }
      
      const res = await fetch('/api/links', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, destination })
      });
      
      if (res.ok) {
        document.getElementById('code').value = '';
        document.getElementById('destination').value = '';
        showToast('Link created successfully!', 'success');
        loadLinks();
      } else {
        const data = await res.json();
        showToast(data.error || 'Failed to create link', 'error');
      }
    }
    
    async function deleteLink(code) {
      if (!confirm('Delete this link? This cannot be undone.')) return;
      
      await fetch(\`/api/links/\${code}\`, { method: 'DELETE' });
      showToast('Link deleted', 'success');
      loadLinks();
    }
    
    function copyLink(code) {
      navigator.clipboard.writeText(\`\${baseUrl}/\${code}\`);
      showToast('Link copied to clipboard!', 'success');
    }
    
    function exportLinks() {
      window.location.href = '/api/export';
      showToast('Downloading export...', 'success');
    }
    
    async function importLinks(event) {
      const file = event.target.files[0];
      if (!file) return;
      
      try {
        const text = await file.text();
        const links = JSON.parse(text);
        
        const res = await fetch('/api/import', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(links)
        });
        
        const data = await res.json();
        if (res.ok) {
          showToast(\`Imported \${data.imported} links (\${data.skipped} skipped)\`, 'success');
          loadLinks();
        } else {
          showToast(data.error || 'Import failed', 'error');
        }
      } catch (e) {
        showToast('Invalid JSON file', 'error');
      }
      
      event.target.value = '';
    }
    
    function showToast(message, type) {
      const toast = document.getElementById('toast');
      toast.textContent = message;
      toast.className = \`toast \${type} show\`;
      setTimeout(() => toast.classList.remove('show'), 3000);
    }
    
    // Keyboard shortcuts
    document.getElementById('code').addEventListener('keypress', e => {
      if (e.key === 'Enter') document.getElementById('destination').focus();
    });
    
    document.getElementById('destination').addEventListener('keypress', e => {
      if (e.key === 'Enter') addLink();
    });
    
    loadLinks();
  </script>
</body>
</html>`;
}
